#!/bin/sh

/koolshare/scripts/ssrserver_config.sh port
